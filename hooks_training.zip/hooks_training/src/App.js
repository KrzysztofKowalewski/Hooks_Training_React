import logo from './logo.svg';
import './App.css';
import React, {useState} from 'react'
import 'bootstrap/dist/css/bootstrap.css';

function App() {

  const [kursy, ustawkursy] = useState(["Programowanie w C#", "Angular dla początkujących", "Kurs Django"])
  const [imie_nazwisko, ustaw_imie_nazwisko] = useState("")
  const [numer_kursu, ustaw_numer_kursu] = useState(0)
  const [nazwa_kursu, ustaw_nazwe_kursu] = useState("")

  const zmiana_imie_nazwisko = (event) => {
    ustaw_imie_nazwisko(event.target.value)
  }

  const zmiana_numer_kursu = (event) => {
    ustaw_numer_kursu(event.target.value)
  }

  const zmiana_nazwa_kursu = (event) => {
    ustaw_nazwe_kursu(event.target.value)
  }

  const wyslij_formularz = (e) => {
    e.preventDefault()
    console.log(imie_nazwisko);
    if(numer_kursu > 0 && numer_kursu < kursy.length){
      console.log("Wybrany kurs to: " + kursy[numer_kursu-1])
    }
    else{
      console.log("Nieprawidłowy numer kursu")
    }
  }

  return (
    <div className="container">
        <h2>Liczba kursów: {kursy.length}</h2>
        <ol>
          {kursy.map((e,index) => {
             return <li key={index}>{e}</li>
          })}
        </ol>
        <form>
          <div className='form-group'>
            <label className='label'>Imię i nazwisko:</label> <br></br>
            <input type="text" className='form-control' onChange={zmiana_imie_nazwisko}></input>
          </div>
          <div className='form-group'>
            <label className='label'>Numer kursu: </label> <br></br>
            <input type='number' className='form-control' onChange={zmiana_numer_kursu}></input>
            <br></br>
          </div>
          <button className='btn btn-primary' onClick={wyslij_formularz}>Zapisz do kursu</button>
        </form>
    </div>
  );
}

export default App;
